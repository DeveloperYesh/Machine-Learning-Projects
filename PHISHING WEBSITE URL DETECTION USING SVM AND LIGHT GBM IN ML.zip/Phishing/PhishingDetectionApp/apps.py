from django.apps import AppConfig


class PhishingdetectionappConfig(AppConfig):
    name = 'PhishingDetectionApp'
